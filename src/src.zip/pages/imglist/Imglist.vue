<!--  -->
<template>
  <div class='imglist'>
    <!-- <List/> -->
    <Class/>
  </div>
</template>

<script>
import List from 'components/daiqin/List.vue'
import Class from 'components/daiqin/Class.vue'
export default {
  name: 'Imglist',
  components: {
    List,
    Class
  }
}
</script>

<style scoped>
</style>
