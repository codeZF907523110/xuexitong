<template>
  <common-title :tilename="'收件地址'" :successshow="false"></common-title>
</template>

<script>
import commonTitle from 'components/common-title/common-title.vue'
export default {
  components: { commonTitle },

}
</script>

<style>

</style>