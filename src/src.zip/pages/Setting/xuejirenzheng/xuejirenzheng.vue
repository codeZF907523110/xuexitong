<template>
<common-title :tilename="'学籍认证'" :successshow="false"></common-title>
  <!-- <h1>ccc</h1> -->
</template>

<script>
import commonTitle from 'components/common-title/common-title.vue'
export default {
  components: { commonTitle },

}
</script>

<style>

</style>