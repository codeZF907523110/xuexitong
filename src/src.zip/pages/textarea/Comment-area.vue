<template>
  <div class="textarea">
    <header-top></header-top>
    <div class="textarea-center">
      <div class="textarea-left">
        <div class="textareaitem" v-for='item in fabuitem'>
          <dynamicitem :fabuitemli="item"></dynamicitem>
        </div>
      </div>
      <div class="textarea-right">
        <global-write></global-write>
        <div class='card'>
          <div v-for="(item,index) in cardtext">
            <carditem :cardtext="item" :cardmess="cardmess[index]" ></carditem>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Carditem from "../../components/Carditem/carditem.vue";
import dynamicitem from "../../components/dynamicitem/dynamicitem.vue";
import GlobalWrite from "../../components/GlobalWrite/GlobalWrite.vue";
import HeaderTop from "../../components/HeaderTop/HeaderTop.vue";
import axios from 'axios'
export default {
  data(){
    return{
        cardtext:['我的收藏','我的关注','我的发布','我的评论','帮助中心','版权服务中心'],
        cardmess:['0','0','1'],
        fabuitem:[]
    }
  },
  components: { dynamicitem, GlobalWrite, HeaderTop, Carditem },
  created(){
    axios.get('/server').then(res=>{
        this.fabuitem=res.data.reverse()
        console.log(res.data);
    })
  }
};
</script>

<style>
.dynamicitem{
  background-color: white;
}
.card{
  width: 296px;
  height: 296px;
  /* border:1px solid red; */
  margin-top: 10px;
}
.textarea-center {
  width: 1120px;
  position: absolute;
  background-color: white;
  left: 50%;
  transform: translateX(-48%);
  /* height: 500px; */
}
.textarea-left {
  width: 750px;
  float: left;
  margin-left: 20px;
}
.textarea {
  width: 100%;
}
.textareaitem {
  width: 750px;
  margin: 0 auto;
}
.textareaitem {
  border-bottom: 1px solid rgb(228, 228, 228);
  margin-top: 20px;
}
.textarea-right {
  /* position: absolute; */
  float: left;
  margin-left: 2%;
  height: 1151px;
  /* border: 1px solid red; */
}
</style>