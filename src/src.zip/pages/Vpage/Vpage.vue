<!--  -->
<template>
  <div class="video">
    <Nav />
    <Vwarp :id="$route.params.id" />
    <Bottom />
  </div>
</template>

<script>
import Nav from "components/daiqin/Nav.vue";
import Vwarp from "components/daiqin/v-warp.vue";
import Bottom from "components/daiqin/Bottom.vue";

export default {
  name: "Vpage",
  components: {
    Nav,
    Vwarp,
    Bottom,
  },
};
</script>

<style scoped>
.video {
  padding-top: 50px;
}
/* 移动端适配 */
@media screen and (max-width: 768px) {
  Nav {
    display: none;
  }
  .video {
    padding-top: 0px;
  }
}
</style>
