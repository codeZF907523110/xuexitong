<template>
  <div class="homepage">
    <header-top></header-top>
    <div class="home-top">
      <div class="home-img">
        <img class='topimg' src="./homepage1.webp" alt="" />
        <div class="myhome">
          <div  class="myhometouxiang">
            <img
              :src="$store.state.userinfo.headphoto"
              class="myhometouxiang"
              alt=""/>
          </div>
          <div class='myhomeuser'>
              <div class='myname'>
                  {{$store.state.userinfo.name}}
                  <a href="">
                      <i>9</i>
                  </a>
              </div>

              <div class='myqianming'>
                  <span>个性签名:</span>
                  {{$store.state.userinfo.signature}}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="home-head">
        <div class='headitems'>
            <div class='headflot' v-for='(item,index) in headitemimg' @click='gotohh(index)' :class='{changblue:changebluee==index}'>
                <headitem :headitemimg="item" :itemtext="itemtext[index]"></headitem>
            </div>
        </div>
        <div class='headstatis'>
          <div class='headstati'>
            <span class='span1'>我的关注</span>
            <span class='span2' v-if='$store.state.userinfo.attention'>{{$store.state.userinfo.attention.length}}</span>
          </div>
          <div class='headstati'>
            <span class='span1'>我的粉丝</span>
            <span class='span2' v-if='$store.state.userinfo.fans'>{{$store.state.userinfo.fans.length}}</span>
          </div>
          <div class='headstati headstatinone'>
            <span class='span1'>点赞数</span>
            <span class='span2'>10</span>
          </div>
        </div>
    </div>
    <!-- <collection></collection> -->
    <router-view></router-view>
  </div>
</template>

<script>
import HeaderTop from '../../components/HeaderTop/HeaderTop.vue';
import headitem from '../../components/headitem/headitem.vue';
import Collection from '../../components/homepageitem/collection.vue';
import Dynamic from '../../components/homepageitem/dynamic.vue';
export default {
    data(){
        return{
            headitemimg:[require('./home.png'),
                    require('./dongtai.png'),
                    require('./like.png'),
                    require('./shoucang.png'),
                    require('./set.png'),
                    require('./set.png')],
            itemtext:['主页','动态','喜欢','收藏','设置','更多'],
            changebluee:0,
            thisrouterpath:['/home','/dynamic','/like','/collection','/setting','']
        }
    },
  components: { headitem, Dynamic,HeaderTop, Collection },
  methods:{
      gotohh(index){
          this.changebluee=index
          this.$router.push('/homepage'+this.thisrouterpath[index])
      }
  }
  };
</script>

<style>
.myqianming:hover{
  color: white;

}
.homepage{
  width: 1285px;
  margin: 0 auto;
  height: auto;
  background-color: white;
}
.changblue{
        color: #00a1d6;
        border-bottom: 3px solid #00a1d6
    }

.headstatis{
    width: 290px;
    height: 100%;
    float: right;
    /* margin-right: 5px; */
}
.headstati{
  float: left;
  width: 80px;
  height: 100%;
  text-align: center;
  cursor: pointer;
}
.headstatinone{
 cursor: default; 
}
.headstati .span1{
  /* color:#00a1d6; */
  display: block;
  margin-top:13px;
  font-size: 13px;
}
.headstati .span2{
  font-size: 14px;
}
.headstati:hover{
  color:#00a1d6!important;
}
.headflot{
    float: left;
    margin-left: 30px;
}
.headflot:hover{
    color: #00a1d6;
    border-bottom: 3px solid #00a1d6
}
.headitems{
    width: 610px;
    height: 100%;
    float: left;
}
.home-head{
    height: 66px;
    width: 1283px;
    margin: 0 auto;
    margin-top: -4px;
}
.myname,.myqianming{
    height: 50%;
}
.myname{
    line-height: 60px;
    color: white;
    font-weight: 800;
    font-size: 20px;
}
.myqianming{
    font-size: 10px;
    color: #d6dee4;
    line-height: 28px;
    min-width: 20px;
}
.myhomeuser{
    width: 300px;
    height: 100%;
    margin-left: 95px;
}
.home-top {
  width: 100%;
}
.myhome {
    height: 84px;
  position: absolute;
  top: 180px;
}
.myhometouxiang {
  width: 64px;
  height: 64px;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  margin-left: 10px;
}
.home-img,
.myhome {
  width: 1283px;
  margin: 0 auto;
}
.myhometouxiang {
  width: 64px;
  height: 64px;
  border-radius: 50%;
}
</style>