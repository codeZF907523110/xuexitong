<template>
  <div>
      <header-top></header-top>
      <classmate></classmate>
  </div>
</template>

<script>
import HeaderTop from '../../components/HeaderTop/HeaderTop.vue'
import Classmate from './Classmate'
export default {
  components: { HeaderTop, Classmate },

}
</script>

<style>

</style>