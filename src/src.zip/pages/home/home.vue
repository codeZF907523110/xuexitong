<!--  -->
<template>
  <div class="home">
    <header-top></header-top>
    <!-- <Nav /> -->
    <Swiper />
    <!-- <Exam/> -->
    <!-- <Server /> -->
    <!-- <T/>   -->
    <!-- <V /> -->
    <!-- <Class/> -->
    <Bottom />
    <!-- <Search/> -->
  </div>
</template>


<script>
import Swiper from "components/daiqin/Swiper.vue";
import Exam from "components/daiqin/Exam.vue";
import T from "components/daiqin/t.vue";
import Server from "components/daiqin/Server.vue";
import Bottom from "components/daiqin/Bottom.vue";
import Nav from "components/daiqin/Nav.vue";
import Search from "components/daiqin/Search.vue";
import V from "components/daiqin/v.vue";
import Class from "components/daiqin/Class.vue";
import HeaderTop from 'components/HeaderTop/HeaderTop.vue';

export default {
  name: "Home",
  components: {
    Swiper,
    Exam,
    T,
    Server,
    Bottom,
    Nav,
    Search,
    V,
    Class,
    HeaderTop,
  },
};
</script>

<style scoped>
body {
  overflow: hidden;
}
</style>
