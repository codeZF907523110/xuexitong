<!--  -->
<template>
  <div>
    <a href="" class="item">
       <div class="img" :style="{ 'background-image': 'url('+classlist+')' }">
    </div>
    <div class="info">
      <p class="title">
        <!-- {{ classlist.title }} -->标题假装很长很长很长很长很长很长
      </p>
      <p class="number"><!--{{ classlist.number }}-->3人报名</p>
    </div>
    <div class="bottom clearfix">
      <span class="discount l"> <i class="name">限时优惠</i> </span>
      <span class="price l red bold">￥<!--{{ classlist.price }}-->123</span>
    </div>
  </a>
  </div>
  
</template>

<script>
import HeaderTop from 'components/HeaderTop/HeaderTop.vue';
export default {
  components: { HeaderTop },
  name: "classlist",
  props: {
    classlist: String,
  },
};
</script>

<style scoped>
a.item {
  position: relative;
  width: 270px;
  height: 272px;
  margin: 20px;
  background: #ffffff;
  box-shadow: 0 6px 10px 0 rgb(95 101 105 / 15%);
  border-radius: 8px;
  float: left;
  overflow: hidden;
  transition: all 0.2s;
}

.hot::before {
  background-image: url();
}
.item .img {
  height: 152px;
  width: 100%;
  margin-bottom: 8px;
  border-radius: 8px;
  position: relative;
  overflow: hidden;
}
.item .img {
  background-size: cover;
  background-position: top center;
}
.item .img img {
  width: auto;
  height: 100%;
  position: absolute;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
}
p.title {
  color: #545c63;
  text-align: left;
  line-height: 20px;
  font-size: 18px;
  height: 40px;
  margin-bottom: 8px;
  padding: 0 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
p.number {
  display: block;
  color: #9199a1;
  font-size: 12px;
  margin-bottom: 8px;
  padding: 0 8px;
}
.item > div.bottom {
  font-size: 12px;
  color: #9199a1;
  line-height: 18px;
  padding: 0 8px;
  margin-bottom: 18px;
}
.l {
  float: left;
}
.bottom .discount {
  border: 1px solid rgba(242, 13, 13, 0.2);
  border-radius: 2px;
  font-size: 12px;
  line-height: 1;
  margin-right: 4px;
  overflow: hidden;
  display: -webkit-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
}
i.name {
  font-style: normal;
  color: #fff;
  background-color: rgba(242, 13, 13, 0.6);
}

.price {
  line-height: 20px;
  margin-right: 2px;
}
.red {
  color: #f01414;
}
.bold {
  font-weight: 700 !important;
}

/* 移动端适配 */
@media screen and (max-width: 768px) {
  a.item {
    width: 100%;
    height: 140px;
    margin: 20px 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .item .img {
    height: 110px;
    width: 110px;
    margin: 0;
    margin-left: 15px;
  }
  .item .title {
    padding: 0;
    font-size: 16px;
    line-height: 20px;
    text-align: center;
  }
  .item .number {
    font-size: 14px;
    text-align: right;
  }
  .item .discount {
    display: none;
  }
  .item .price {
    display: block;
    width: 60px;
    height: 30px;
    margin-right: 10px;
    background: rgba(43, 51, 59, 0.06);
    border-radius: 50px;
    font-weight: 500;
    font-size: 13px;
    color: #71777d;
    text-align: center;
    line-height: 30px;
  }
  .info {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 20px 0;
    width: 110px;
  }
}
</style>
