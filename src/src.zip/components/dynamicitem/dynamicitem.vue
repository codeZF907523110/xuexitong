<template>
  <div class="dynamicitem">
    <div class="userinfo">
      <div class="touxiangbox">
        <img :src="fabuitemli.headphoto" alt="" />
      </div>
      <div class="userbox">
        <div class="usernamebox">
          <span>{{fabuitemli.auther}}</span>
          <img src="" alt="" />
        </div>
        <div class="releasetime">
          <span>{{fabuitemli.createdtime}}小时前</span>
          <span class="userfrom">来自:</span>
        </div>
      </div>
    </div>
    <div class='releaseleft'>
      <div class="releasetitle">
      <span>
          <span v-html='fabuitemli.content'></span>
          <a href="" class='lookglobo' v-show='false'>...查看全部</a>
      </span>
      </div>
      <div v-show="false" class="releaseimg">
        <img class='fenmian' :src="fabuitemli.cover" alt="" />
        <div class='showvideo' v-show='false'>
            <img src="./video.png" alt="">
        </div>
        <div v-show='true' class="releaseimgtext">
          <div class="imgtext-top">
            <div class="imgtext-top-left" v-if='fabuitemli.fabuimgleft'>{{fabuitemli.fabuimglaft}}</div>
            <div class="imgtext-top-right" v-show='false'>文章</div>
          </div>
          <div class="imgtext-bottom" v-show='!fabuitemli.fabuimgtitle'>
            {{fabuitemli.title}}
          </div>
        </div>
        <div class="releaseimgtext" v-show='true'>
          <div class="imgtext-bottom imgtexttwo" v-show='fabuitemli.playvolume'>
            <span>{{fabuitemli.playvolume}}次播放</span>
            <span class="imgtexttwo-right">{{fabuitemli.duration}}</span>
          </div>
        </div>
      </div>
      <div class='useractive'>
          <div class='forward'>
              <img src="./forward.png" alt="">
              <span>{{fabuitemli.comment.length}}</span>
          </div>
          <div class='comment'>
              <img src="./comment.png" alt="">
              <span>{{fabuitemli.comment.length}}</span>
          </div>
          <div class='fabulous'>
              <img src="./fabulous.png" alt="">
              <span>{{fabuitemli.likes.length}}</span>
          </div>
          <div class='Collection'>
              <img src="./Collection.png" alt="">
              <span>{{fabuitemli.star.length}}</span>
          </div>
      </div>
    </div>
    
  </div>
</template>

<script>
export default {
  data(){
    return{
      wenzhang:{}
    }
  },
  props:{
    fabuitemli:Object
  },
  created(){
    console.log(this.fabuitemli);
    
  }
};
</script>

<style>
.releaseleft{
  margin-left: 60px;
}
.useractive {
  height: 40px;
  margin-bottom: 2px;
}
.useractive img {
  width: 28%;
  cursor: pointer;
  float: left;
  margin-top: 8px;
}
.useractive div {
  float: left;
  height: 100%;
  line-height: 40px;
  width: 80px;
}
.useractive div span {
  display: block;
  float: left;
  margin-left: 5px;
}
.showvideo {
  z-index: 999999999999999;
  cursor: pointer;
  width: 67.5px;
  height: 67.5px;
  border-radius: 50%;
  background-color: rgba(0, 0, 0, 0.5);
  position: absolute;
  float: left;
  left: 50%;
  transform: translateX(-50%);
  top: 35%;
}
.dynamicitem{
    border-bottom: 1px solid rgb(241, 241, 241);
    margin-top: 10px;
}
.showvideo img {
  width: 80%;
  height: 80%;
  display: block;
  /* margin: 0 auto; */
  /* background-color: white; */
  left: 50%;
  position: absolute;
  transform: translateX(-50%);
  top: 10%;
}
.imgtexttwo-right {
  float: right;
}
.imgtexttwo {
  margin-top: 70px;
}
.releaseimgtext {
  z-index: 99999;
}

.touxiangbox {
  width: 40px;
  height: 40px;
  float: left;
  cursor: pointer;
}
.touxiangbox img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
}
.usernamebox {
  font-size: 18px;
}
.usernamebox span {
  cursor: pointer;
}
.releasetime {
  font-size: 15px;
  color: #939393;
}
.userfrom {
  margin-left: 10px;
}
.userbox {
  padding-left: 40px;
  margin-left: 15px;
}
.releasetitle {
  max-height:200px;
  font-size: 21px;
  line-height: 35px;
  overflow: hidden;
}
.releasetitle img{
  display: none;
}
.releaseimg {
  width: 400px;
  height: 225px;
  overflow: hidden;
  margin-top: 20px;
  position: relative;
}
.fenmian {
  width: 100%;
  position: relative;
  float: left;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}
.releaseimgtext {
  width: 85%;
  height: 85%;
  position: absolute;
  margin-top: 0;
  float: left;
  margin: 0 auto;
  left: 50%;
  transform: translateX(-50%);
  color: white;
  font-size: 18px;
}
.imgtext-top-right {
  float: right;
  font-size: 13px;
  cursor: pointer;
}
.imgtext-top-left {
  float: left;
}
.imgtext-top {
  margin-bottom: 20px;
  height: 40px;
  line-height: 40px;
}
.imgtext-bottom {
  /* height: 100%; */
  padding-top: 35%;
  font-size:20px;
}
</style>