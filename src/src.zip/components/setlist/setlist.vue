<template>

      <div>{{listname}}<img src="./rightjian.png" alt=""></div>

</template>

<script>
export default {

    props:{
        listname:String
    }
}
</script>

<style>

</style>