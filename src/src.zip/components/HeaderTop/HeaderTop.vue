<template>
  <div class="HeaderTop">
    <div class="Headertop container">
      <div class="logo">
        <div class="menubutton" @click="menusideshow">
          <span></span>
          <span></span>
          <span></span>
        </div>
        <img src="./logo.jpg" @click="changmsite" class="logoimg" alt="" />
      </div>
      <div class="Header-text">
        <a @click="$router.push('/classification')">推介课程</a>
        <a>专属教程</a>
        <a @click="$router.push('/textarea')">动态</a>
      </div>

      <div class="search">
        <input type="text" class="search-input" placeholder="请输入关键字..." />
        <img src="./search.png" alt="" class="search-img" />
      </div>
      <div class="Headermessage">
        <img class="messageimg" src="./message.png" alt="" />
      </div>
      <div class="HeaderText" v-if="!$store.state.userinfo.name">
        <a class="HeaderText wodeshoucang">我的收藏</a>
        <a class="Header-Login" @click="login">登录</a>
        <span class="loginspan">/</span>
        <a class="Header-Logon" @click="logon">注册</a>
      </div>    
      <div v-else class="HeaderText">
        <a class="HeaderText wodeshoucang">我的收藏</a>
        <a class="HeaderText wodeshoucang">我的课程</a>
        <div class="Header-div" @mouseover="mouseOver" @mouseout="mouseOut">
          <img
            class="touxiang"
            @click="gotosetting('/homepage')"
            :src="$store.state.userinfo.headphoto"
            alt=""
          />
          <div
            class="formation"
            v-show="isActive"
            @mouseover="mouseOver"
            @mouseout="mouseOut"
          >
            <header-topin-formation :shujv="shujv"></header-topin-formation>
          </div>
        </div>
      </div>
    </div>
    <login v-show="$store.state.loginshow"></login>
    <sidebar v-show="$store.state.sideshow"></sidebar>
  </div>
</template>
<script>
import Login from "../Login/Login.vue";
import Sidebar from "../Sidebar/sidebar.vue";
import HeaderTopinFormation from "./HeaderTopinFormation.vue";
// import{getHomeMultidata}from '../../api/network/gather'
export default {
  data() {
    return {
      isActive: false,
      shujv: this.$store.state.userinfo,
    };
  },
  methods: {
    gotosetting(path) {
      this.$router.push(path);
    },
    mouseOver() {
      this.isActive = true;
    },
    mouseOut() {
      this.isActive = false;
    },
    login() {
      this.$store.state.ischangecolor = true;
      this.$store.state.loginshow = true;

      // this.$store.state.islogin=true
      // this.$store.state.isshow=true
    },
    logon() {
      this.$store.state.ischangecolor = false;
      this.$store.state.loginshow = true;
      // this.$store.state.islogin=true
      // this.$store.state.isshow=true
    },
    changmsite() {
      this.$router.push("/msite/123");
      console.log(this.$route.params.id);
    },
    menusideshow() {
      this.$store.state.sideshow = true;
    },
  },
  components: { HeaderTopinFormation, Login, Sidebar },
};
</script>
<style>
body {
  width: 100%;
  height: 100%;
}
.Header-div {
  float: left;
  width: 35px;
  height: 35px;
  position: relative;
  height: 72px;
}
.wodeshoucang {
  float: left;
}
.showinformation-enter-active,
.show-leave-active {
  transition: all 2s;
}
.menubutton {
  width: 25px;
  height: 25px;
  border-radius: 8px;
  display: none;
  z-index: 1000;
  margin-top: 10px;
  margin-left: 10px;
}
.menubutton span {
  display: block;
  height: 4px;
  width: 95%;
  background-color: rgb(172, 172, 172);
  border-radius: 5px;
  margin-top: 5px;
}
.quite :hover {
  font-weight: bold;
}
input {
  outline: none;
}
.Header-text {
  float: left;
  text-align: center;
  font-size: 16px;
  height: 72px;
  line-height: 72px;
}
.Header-text :hover {
  font-weight: 600;
  cursor: pointer;
}
.Header-text a {
  margin-left: 35px;
}
.touxiang {
  width: 32px;
  height: 32px;
  /* border:1px solid black; */
  border-radius: 50%;
  position: absolute;
  margin-top: 20px;
  margin-left: 20px;
}
.Headertop {
  height: 72px;
  width: 1150px;
  margin: 0 auto;
  /* box-shadow: 0 4px 8px 0 rgba(7, 17, 27, 0.1); */
  position: relative;
}
.header-topin-formation {
  position: absolute;

  margin-left: -100px;
}
.HeaderTop {
  background-color: #fff;
  position: relative;
}
.logoimg {
  width: 126px;
  height: 72px;
  float: left;
  cursor: pointer;
}
.search {
  float: left;
  position: relative;
  height: 40px;
  padding-right: 40px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.4);
  zoom: 1;
  background: #e9e9e9;
  border-radius: 8px;
  margin: 16px 70px;
  width: 324px;
  box-sizing: border-box;
  font-size: 0;
}
.formation {
  position: absolute;
  top: 75px;
  left: -50px;
  margin-top: -20px;
  /* border:1px solid red;
           z-index: 9999999999; */
  z-index: 99999999999999;
}
.search-input {
  font-size: 14px;
  color: #a6a6a6;
  line-height: 24px;
  height: 40px;
  width: 100%;
  float: left;
  border: 0;
  background-color: transparent;
  /* border: 1px solid red; */
}
.search-img {
  width: 13%;
  /* margin-top: -80px; */
  /* margin-left: 100%; */
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  border-left: 1px solid rgb(109, 109, 109);
}
.HeaderText {
  width: auto;
  color: #71777d;
  cursor: pointer;
  line-height: 72px;
  margin-left: 3%;
}
.HeaderText :hover {
  color: red;
}
.Header-Login {
  margin-left: 50px;
}
.Headermessage {
  /* width: 100%; */
  width: 20px;
  height: 72px;
  float: left;
  /* margin-left: 10%; */
}
.messageimg {
  width: 20px;
  height: 20px;
  float: left;
  margin-top: 28px;

  cursor: pointer;
}
@media screen and (max-width: 768px) {
  body {
    width: 100%;
    height: 100vh;
  }
  .logoimg {
    display: none;
  }
  .menubutton {
    display: block;
    float: left;
    /* margin-left: 10px; */
  }
  .Headertop {
    width: 100%;
    height: 50px;
    border-bottom: 1px solid rgb(131, 131, 131);
  }
  .Header-text {
    display: none;
  }
  .search {
    /* margin-top: 10px; */
    position: absolute;
    height: 30px;
    border-radius: 30px;
    width: 60%;
    float: left;
    margin-top: 10px;
  }
  .search input {
    height: 100%;
    font-size: 12px;
    margin-left: 25px;
  }
  .search img {
    /* display: none; */
    border: none;
    position: absolute;
    margin-left: -95%;
    width: 20px;
    border-right: 1px solid rgb(173, 173, 173);
  }
  .wodeshoucang {
    display: none;
  }
  .Header-Login {
    float: left;
    margin-left: 75%;
  }
  .Header-Login,
  .Header-Logon {
    /* position: absolute; */

    font-size: 13px;
    height: 100%;
    line-height: 50px;
  }
  .Header-Logon {
    float: left;
    margin-left: 3px;
  }
  .Headermessage {
    display: none;
  }
  .loginspan {
    display: none;
  }
  .touxiang {
    width: 30px;
    height: 30px;
    margin-top: 30%;
    /* position: absolute; */
  }
  .Header-div {
    /* border:1px solid red; */
    width: 33px;
    height: 100%;
    position: absolute;
    margin-left: 80%;
  }
  .formation {
    display: none;
  }
}
</style>