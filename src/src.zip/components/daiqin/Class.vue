<!--  -->
<template>
  <div class="class">
    <Classlist
      v-for="(item, index) in classlist"
      :key="index"
      :classlist="item"
    />
  </div>
</template>

<script>
import axios from "axios";
axios.defaults.baseURL = "http://81.70.192.127:808";
import Classlist from "components/Classlist.vue";
export default {
  name: "Class",
  data() {
    return {
      classlist: []
    };
  },
  components: {
    Classlist,
  },
  created() {
    // axios.get("/getclasslist").then((res) => {
    //   this.classlist = res;
    // });
    axios.get("/getv").then((res) => {
      this.classlist = res.data;
    });
  },
};
</script>

<style scoped>
.class {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
@media screen and (max-width: 768px) {
  .class {
    padding-bottom: 49px;
  }
}
</style>
