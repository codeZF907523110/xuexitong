<!--  -->
<template>
  <div class="putdata container">
    <div class="title">
      <h1 class="h1">
        文件上传<span>（推荐采用mp4、flv格式，可有效缩短审核转码耗时）</span>
      </h1>
    </div>
    <div class="file_list">
      <div class="logo"></div>
      <h2 class="h2">123</h2>
    </div>
    <!-- 进度条 -->
    <div class="progress">
      <div
        class="progress-bar"
        role="progressbar"
        aria-valuenow="2"
        aria-valuemin="0"
        aria-valuemax="100"
        style="min-width: 2em; width: 2%"
        :style="{ width: rate + '%' }"
      >
        {{ rate }}%
      </div>
    </div>
    <!-- 文件 -->
    <div class="form-group">
      <input type="text" id="title" v-model="title" />标题
      <input type="file" id="imgFile" @change="changeimg" />封面图片
      <input type="file" id="exampleInputFile" @change="changeFile" />视频内容
      <p class="help-block">Example block-level help text here.</p>
      <button type="submit" class="btn btn-default" @click="uploadFile">
        Submit
      </button>
    </div>
    <h1>{{ title }}</h1>
  </div>
</template>

<script>
import axios from "axios";
axios.defaults.timeout = 10000;
axios.defaults.baseURL = "http://81.70.192.127:808";
export default {
  name: "",
  data() {
    return {
      video: "",
      title: "",
      file: "",
      rate: 0,
      img: "",
    };
  },
  methods: {
    uploadFile() {
      let formData = new FormData();
      let config = {
        //必须
        headers: {
          "Content-Type": "multipart/form-data",
        },
        //获取上传进度, 可去掉
        onUploadProgress: function (progressEvent) {
          let complete =
            ((progressEvent.loaded / progressEvent.total) * 100) | 0;
          console.log(complete + "%");
        },
      };
      formData.append("file", this.file);
      formData.append("title", this.title);
      formData.append("img", this.img);
      axios.post("/put", formData).then((res) => {
        // this.video = res.data.name;
        console.log(res);
      });
    },
    changeFile(e) {
      this.rate = 0;
      this.file = e.target.files[0];
      this.title = this.file.name;
    },
    changeimg(e) {
      this.img = e.target.files[0];
    },
  },
};
</script>

<style scoped>
video {
  height: 200px;
  width: 100%;
  background: oldlace;
}
.title {
  padding: 12px 0;
}
h1 span {
  font-size: 12px;
}
.file_list {
  padding: 12px 0px;
  display: flex;
  justify-content: space-between;
}
.file_list h2 {
  flex: 1;
  margin-left: 22px;
}
.logo {
  width: 140px;
  height: 66px;
  background: rgb(167, 154, 154);
}
</style>
