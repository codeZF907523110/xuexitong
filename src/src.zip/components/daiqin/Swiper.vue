<!--  -->
<template>
  <div class="swiper-container swiper">
    <div class="swiper-wrapper">
      <div class="swiper-slide">1</div>
      <div class="swiper-slide">2</div>
      <div class="swiper-slide">3</div>
      <div class="swiper-slide">4</div>
      <div class="swiper-slide">5</div>
      <div class="swiper-slide">6</div>
    </div>
    <!-- 如果需要分页器 -->
    <div class="swiper-pagination fenye"></div>
  </div>
</template>

<script>
import "swiper/swiper-bundle.min.css";
import { Swiper, Navigation, Pagination, Autoplay } from "swiper";

export default {
  name: "Swiper",
  data() {
    return {
      imgList: {},
    };
  },
  created() {},
  mounted() {
    //swiper6提供了use方法，其他写法没有啥区别和swiper4、5一样
    Swiper.use([Navigation, Pagination, Autoplay]);
    var recommendswiper = new Swiper(".swiper", {
      // direction: 'vertical', // 垂直切换选项
      loop: true, // 循环模式选项
      autoplay: {
        delay: 3000,
      },
      // 如果需要分页器
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });
  },
};
</script>

<style>

.swiper {
  padding-top: 51px;
  box-sizing: border-box;
  text-align: center;
}

.swiper .swiper-slide {
  height: 56vh;
  background: red;
  text-align: center;
  line-height: 46vh;
  font-size: 99px;
}
.swiper .fenye  .swiper-pagination-bullet {
  background: rgba(255, 255, 255, 0.75);
  transition: all 0.2s;
  opacity: 1;
  border-radius: 4px;
}
.swiper .fenye .swiper-pagination-bullet-active {
  width: 20px;
}
</style>
